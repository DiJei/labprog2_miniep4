import sys
import math

def test_arctan(x):
	arc = 0
	for i in range(0,12):
		aux1 = math.pow(-1,i)
		aux2 = 2*i + 1
		aux3 = math.pow(x,aux2)
		arc = arc + (aux3 * aux1) / math.factorial(aux2)
	print(arc)

n = float(sys.argv[1])
test_arctan(n)
print(math.atan(n))