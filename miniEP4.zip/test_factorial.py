import sys
import math

def test_factorial(n,episolon):
   c = 1
   for i in range(1, n + 1) :
      c = c * i
   print(c)
   if c - math.factorial(n) < episolon :
      print("Passou")
   else :
      print("Não passou")

test_factorial(int(sys.argv[1]),float(sys.argv[2]))       