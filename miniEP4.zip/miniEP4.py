import sys
import math
import unittest
# coloque na entrada o valor do epsilon #
epsilon = 0.000001

class mathPyTest(unittest.TestCase):
    def __sen(x):
       sin = 0
       for i in range(0, 11):
          aux1 = math.pow(-1,i)
          aux2 = math.pow(x,2*i + 1)
          aux3 = math.factorial(2*i + 1)
          sin = sin + (aux1 * aux2) / aux3
       return sin  

    def test_sen(self):
      self.assertGreaterEqual(epsilon,math.fabs(sen(3.1429) - math.sin(3.1429)))


if __name__ == '__main__':
    unittest.main()