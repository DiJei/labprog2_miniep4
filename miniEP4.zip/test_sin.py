import sys
import math

def test_sen(x,episolon):
	sin = 0
	for i in range(0, 11):
	  aux1 = math.pow(-1,i)
	  aux2 = math.pow(x,2*i + 1)
	  aux3 = math.factorial(2*i + 1)
	  sin = sin + (aux1 * aux2) / aux3
	if (math.fabs(sin - math.sin(x))) < episolon:
	   print("Passou")
	else:
	   print("Não passou")    

n = float(sys.argv[1])
episolon = float(sys.argv[2])
test_sen(n, episolon)