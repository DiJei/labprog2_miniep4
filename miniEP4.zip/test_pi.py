import sys
import math
def test_pi(episolon):
   myPi = 3.14159265359 # para testar
   if(math.fabs(myPi - math.pi) > episolon): #vou ter quer mudar para um assert
      print("Não passou")
   else:
      print("Passou")

n = float(sys.argv[1])
test_pi(n)    