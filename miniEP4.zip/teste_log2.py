import sys
import math

#Usa base 10 para calcular base 2
def test_log2 (n,episolon):
	
	if math.fabs( math.log10(n) / math.log10(2) - math.log(n,2) ) > episolon : 
		print("Não passou")
	else :
	    print("Passou")


n = float(sys.argv[1])
episolon = float(sys.argv[2])

test_log2(n,episolon)		