import sys
import math
def test_pi(episolon):
   myPi = 3.141559265359
   if(mypi - math.pi > episolon): #vou ter quer mudar para um assert
      printf("Não passou")
   else:
      printf("Passou")

n = argv[1]
test_pi(n)   